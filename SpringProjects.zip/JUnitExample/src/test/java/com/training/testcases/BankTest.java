package com.training.testcases;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.training.example.Bank;
import com.training.example.DNegValueException;
import com.training.example.ENegValueException;
import com.training.example.ExceedingException;
import com.training.example.NegValueException;

class BankTest {
	Bank bank;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
		System.out.println("before all test cases");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("after all test cases");
	}

	@BeforeEach
	void setUp() throws Exception {
		bank=new Bank(8000);
		System.out.println("before each test case");
	}

	@AfterEach
	void tearDown() throws Exception {
		bank=null;
		System.out.println("after each test cases");
	}

	@Test
	void testwithdraw() {
		double balance=bank.withdraw(2000);
		assertEquals(6000,balance,"should be 6000");
	}
	@Test
	void testdeposit() {
		double balance=bank.deposit(5000);
		assertEquals(13000,balance,"should be 13000");
	}
	
	@Test
	void testwithdrawException() {
		Assertions.assertThrows(ExceedingException.class, ()->bank.withdraw(9000));
	}
	@Test
	void testwithdrawNeg() {
		assertThrows(NegValueException.class, ()->bank.withdraw(-900));
	}
	
	@Test
	void testDepositNeg() {
		assertThrows(DNegValueException.class, ()->bank.deposit(-900));
	}
	@Test
	void testDepositExceed() {
		assertThrows(ENegValueException.class, ()->bank.deposit(45000));
	}

}
