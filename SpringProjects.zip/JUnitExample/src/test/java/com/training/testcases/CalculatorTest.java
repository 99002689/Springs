package com.training.testcases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.training.example.AvgNegValueException;
import com.training.example.Calculator;
import com.training.example.DNegValueException;

class CalculatorTest {
	Calculator calculator;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("before all testcases");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("after all testcases");
	}

	@BeforeEach
	void setUp() throws Exception {
		calculator=new Calculator();
		System.out.println("before each testcase");
	}

	@AfterEach
	void tearDown() throws Exception {
		calculator =null;
		System.out.println("after each testcases");
	}

	@Test
	void testSum() {
		int actual=calculator.sum(10, 20);
		assertEquals(30,actual);
	}
	@Test
	void testSumNeg() {
		int actual=calculator.sum(-10, -20);
		assertEquals(-30,actual);
	}
	@Test
	void testSub() {
		int actual=calculator.sub(10, 20);
		assertEquals(10,actual);
	}
	
	@Test
	void testDiv() {
		double  actual=calculator.div(20, 10);
		assertEquals(2.0,actual);
	}
	
	@Test
	void testAvgNeg() {
		assertThrows(AvgNegValueException.class, ()->calculator.avg(-20, 10, 5));
	}
	
	@Test
	void testAvg() {
		double  actual=calculator.avg(10, 20, 30);
		assertEquals(20,actual);
	}

}
