package com.training.example;

public class Bank {

	double balance;

	public Bank(double balance) {
		super();
		this.balance = balance;
	}
	
	public double deposit(double amount) {
		if(amount<0) {
			throw new DNegValueException("amount is less than zero");
		}
		if(amount >40000 ) {
			throw new ENegValueException("amount beyong limit");
		}
		balance=balance+amount;
		return balance;
	}
	
	public double withdraw(double amount) throws ExceedingException{
		if(amount >=4000 || amount==balance) {
			throw new ExceedingException("amount beyong limit");
		}
		if(amount <0) {
			throw new NegValueException("amount is less than zero");
		}
		balance=balance-amount;
		return balance;
	}
	
	


}
