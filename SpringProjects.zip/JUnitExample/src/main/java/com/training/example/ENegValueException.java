package com.training.example;

public class ENegValueException extends RuntimeException{

	public ENegValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ENegValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
