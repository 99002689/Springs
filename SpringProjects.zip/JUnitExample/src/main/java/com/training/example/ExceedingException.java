package com.training.example;

public class ExceedingException extends RuntimeException{

	public ExceedingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ExceedingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
