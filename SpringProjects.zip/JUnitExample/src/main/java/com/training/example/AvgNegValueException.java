package com.training.example;

public class AvgNegValueException extends RuntimeException {

	public AvgNegValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AvgNegValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
