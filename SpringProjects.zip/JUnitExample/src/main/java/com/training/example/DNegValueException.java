package com.training.example;

public class DNegValueException extends RuntimeException{

	public DNegValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DNegValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
		
}
