package com.hotel.client;

import java.util.List;

import com.hotelapp.model.Hotel;
import com.hotelapp.service.HotelService;
import com.hotelapp.service.HotelServiceImpl;



public class Customer {



	public static void main(String[] args) {
		HotelService hotelService=new HotelServiceImpl();
		List<Hotel>hotelList=hotelService.getAllHotels();
		for(Hotel hotel:hotelList) {
			System.out.println(hotel);
	}
	
	List<Hotel> hotelList1 = hotelService.getByCuisine("chinise");
    for(Hotel hotel : hotelList1) {
        System.out.println(hotel);
    }
    
    List<Hotel> hotelList2 = hotelService.getByCity("mysuru");
    for(Hotel hotel : hotelList2) {
        System.out.println(hotel);
    }
    Hotel hotel2 = hotelService.getById(1);
        System.out.println(hotel2);
    }
}

