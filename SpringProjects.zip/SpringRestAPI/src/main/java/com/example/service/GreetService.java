package com.example.service;

public interface GreetService {
	String showMessage();
	String welcomeUser(String name);
	String printName(String name);
}
