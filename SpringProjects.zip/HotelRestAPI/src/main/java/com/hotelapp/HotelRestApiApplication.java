package com.hotelapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelRestApiApplication.class, args);
	}

}
