package com.hotelapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hotelapp.model.Hotel;
@Service
public interface HotelService {
	List<Hotel> getAllHotels();
	Hotel getById(int id);
	List<Hotel> getByCity(String city);
	List<Hotel> getByCuisine(String cuisine);
	

}
