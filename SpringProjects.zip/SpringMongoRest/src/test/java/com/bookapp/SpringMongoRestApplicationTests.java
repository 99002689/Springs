package com.bookapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
