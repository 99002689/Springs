package com.lts.training;

public interface GreetService {
	String greet(String name);

}
