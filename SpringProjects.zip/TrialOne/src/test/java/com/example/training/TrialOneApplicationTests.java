package com.example.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrialOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
