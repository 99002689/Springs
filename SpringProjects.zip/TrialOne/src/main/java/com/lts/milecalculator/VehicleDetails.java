package com.lts.milecalculator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class VehicleDetails {
    @Autowired
    @Qualifier("bike")
	MileCalculator calculator;
    @Autowired
    @Qualifier("car")
	MileCalculator ccalculator;
	public void getMileage(String choice) {
		
		if(choice.equals("bike")) {
			calculator.showMileage();
			
		}
		else
			ccalculator.showMileage();
		
	}

}
