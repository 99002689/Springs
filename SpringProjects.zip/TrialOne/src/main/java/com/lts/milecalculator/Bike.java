package com.lts.milecalculator;

import org.springframework.stereotype.Component;

@Component
public class Bike implements MileCalculator {

	@Override
	public void showMileage() {
		System.out.println("Bike mileage is 40");
		
	}

	
}
