package com.hotelapp.service;

import java.util.List;

import com.hotelapp.dao.HotelDAO;
import com.hotelapp.model.Hotel;

public class HotelServiceImpl implements HotelService {
	
	//HotelDAO hotelDAO =new HotelServiceImpl();

	@Override
	public List<Hotel> getAllHotels() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Hotel getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Hotel> getByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Hotel> getByCuisine(String cuisine) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
