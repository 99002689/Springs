package com.lts.milecalculator;

import org.springframework.stereotype.Component;

@Component
public interface MileCalculator {
	
	void showMileage();

}
