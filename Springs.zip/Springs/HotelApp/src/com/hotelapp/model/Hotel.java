package com.hotelapp.model;

public class Hotel {

	Integer Id;
	String name;
	String city;
	String cuisine;
	public Hotel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Hotel(Integer id, String name, String city, String cuisine) {
		super();
		Id = id;
		this.name = name;
		this.city = city;
		this.cuisine = cuisine;
	}


	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	@Override
	public String toString() {
		return "Hotel [Id=" + Id + ", name=" + name + ", city=" + city + ", cuisine=" + cuisine + "]";
	}
	
	

}
