package com.example.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetController {
	@RequestMapping("/greet")
	public String sayHello() {
		
		return "Have a great day";
	}
	
	@GetMapping("/welcome/{username}")
	public String sayWelcome(@PathVariable("username")String name) {
		return "Welcome " +name;
	}
	
	@GetMapping("/hi")
	public String sayHi(@RequestParam("name")String name) {
		return "Hi " +name;
	}
}
